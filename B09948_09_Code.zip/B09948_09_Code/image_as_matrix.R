library(OpenImageR)

clock <- readImage("Alarms_&_Clock_icon.png")

clock[1:10,46:56,4]